---
title       : Muestras complejas con Stata
subtitle    : BUAP
author      : Julio Cesar Martinez Sanchez
job         : INEGI
framework   : io2012        # {io2012, html5slides, shower, dzslides, ...}
highlighter : highlight.js  # {highlight.js, prettify, highlight}
hitheme     : tomorrow      # 
widgets     : []            # {mathjax, quiz, bootstrap}
mode        : selfcontained # {standalone, draft}
knit        : slidify::knit2slides
---
<section class="slide">
  <h2>Contenido del taller</h2>
  <ol>
    <li>
      <h3><b>Teoría</b></h3>
      <h4>Esquema de muestreo</h4>
      <h5>M?todos para calcular la varianza</h5>
    </li>
    <li>
      <h3><b>Práctica</b></h3>
      <h4>Definir el esquema de muestreo</h4>
      <h5>Subpoblaciones (Problemas)</h5>
      <h6>Pruebas de hipótesis</h6>
      <h7>Modelos de regresión</h7>
    </li>
  </ol>
</section>

--- .segue bg:grey

## Esquema de muestreo ###

--- &vcenter 

## Tipos de muestreo

![](https://cloud.githubusercontent.com/assets/13545121/22679257/61557484-ecc6-11e6-819f-6de445b71166.JPG)

Los conglomerados se denominan `Unidades Primarias de Muestreo`, las cuales  son agrupaciones de viviendas con características similares. 

--- &vcenter 

## Unidades Primarias de Muestreo (UPM)

![](https://cloud.githubusercontent.com/assets/13545121/22679668/7499f63e-ecc9-11e6-908a-405119e3dd52.JPG)

Las UPM se encuentran almacenadas en lo denominado como `muestra maestra` y ésta se genera a partir de la información del [marco nacional de viviendas](http://www.inegi.org.mx/eventos/2013/Foro_Estadistica/doc/P-AnaMariaLanderos.pdf)

--- &vcenter
## Número de etapas de selección

![](https://cloud.githubusercontent.com/assets/13545121/22679675/7e393600-ecc9-11e6-8f0a-1b8fa80da41d.JPG)

Para tener una idea de cuál es la metodología del INEGI, se recomienda consultar [Diseño de la muestra en proyectos de encuesta (INEGI)](http://www.snieg.mx/contenidos/espanol/normatividad/doctos_genbasica/muestra_encuesta.pdf)

--- &vcenter 
## Muestra para Puebla

![](https://cloud.githubusercontent.com/assets/13545121/22679679/851942e4-ecc9-11e6-844f-0275c2f27b73.JPG)

--- &vcenter 
## Ponderación

![](https://cloud.githubusercontent.com/assets/13545121/22679750/11b32936-ecca-11e6-840c-48e05844ad7a.JPG)

El último ajuste a las proyecciones demográficas de CONAPO se llevó a cabo en 2013, ver [nota](http://www.beta.inegi.org.mx/contenidos/proyectos/enchogares/regulares/enoe/doc/Nota_Result_Proy.pdf)

--- &vcenter 
##¿Cómo afecta la estratificación, conglomeración y ponderación en los estimadores?

![](https://cloud.githubusercontent.com/assets/13545121/22679752/1a3a57fa-ecca-11e6-830f-e47b60d56555.JPG)

Lo recomendable al momento de analizar un esquema de muestreo complejo es hacer las  [pruebas de significancia estad?stica](http://www.beta.inegi.org.mx/contenidos/proyectos/enchogares/regulares/enoe/doc/enoe_significancia.pdf)

--- .segue bg:grey

## Métodos para calcular la varianza ###

--- &vcenter 
 
## Métodos

![](https://cloud.githubusercontent.com/assets/13545121/22679757/257f2028-ecca-11e6-8b92-54d886287ca8.JPG)

Se recomienda consultar el texto [Applied Survey Data Analysis](http://www.isr.umich.edu/src/smp/asda/) en donde se explica con mayor detalle (conceptual y matemático) cada uno de los m?todos.

--- &vcenter 

## Bootstrap

![](https://cloud.githubusercontent.com/assets/13545121/22679762/2d502338-ecca-11e6-85a0-4d56320a20ee.JPG)

La lógica es que entre más replicas se consideren, se mejora las estimaciones del error estándar; para analizar este comportamiento consultar la página: https://jcms2665.shinyapps.io/BootstrapS

--- &vcenter

## Jackknife y BRR 

![](https://cloud.githubusercontent.com/assets/13545121/22679770/352545de-ecca-11e6-8c4b-afd8c01028e2.JPG)

Para profundizar en el tema, se recomienda consultar a [Chernick y LaBudde (2011)](http://www.ievbras.ru/ecostat/Kiril/R/Biblio/R_eng/Chernick2011.pdf), quienes no sólo dan una explicación matematica con mas detalle, sino su implementación en R.

--- &vcenter
## Linealización por series de Taylor

![](https://cloud.githubusercontent.com/assets/13545121/22679772/3b8346ba-ecca-11e6-91dd-11270ee1c5e4.JPG)

Se recomienda consultar el texto [Sampling Techniques](http://hbanaszak.mjr.uw.edu.pl/StatRozw/Books/Cochran_1977_Sampling%20Techniques.pdf) en donde se detalla paso a paso este m?todo.

--- .segue bg:grey

## Stata ###

--- 
## Consideraciones 
<br>
<br>
<br>
<font size=6><b>1. Las bases de datos, el do-file y el material de apoyo se encuentra en: https://github.com/jcms2665/BUAP </b></font> 
<br>
<br>
<br>
<font size=6><b>2. La ejecución de los comandos paso a paso se encuentra en: http://rpubs.com/jcms2665/SvyStata </b></font>
<br>
---
